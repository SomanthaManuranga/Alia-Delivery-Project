Place these directories in the Webot controllers folder and select the respective controllers in the world file provided in this repository.
